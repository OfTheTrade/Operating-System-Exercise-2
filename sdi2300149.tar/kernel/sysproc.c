#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  kexit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return kfork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return kwait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
  argint(1, &t);
  addr = myproc()->sz;

  if(t == SBRK_EAGER || n < 0) {
    if(growproc(n) < 0) {
      return -1;
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
      return -1;
    if(addr + n > TRAPFRAME)
      return -1;
    myproc()->sz += n;
  }
  return addr;
}

uint64
sys_pause(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  if(n < 0)
    n = 0;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kkill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// ------------------ DIT
#include "pstat.h"
#include "defs.h"
extern struct proc proc[NPROC];
// return info about the proccess
uint64
sys_getpinfo(void)
{
  struct pstat st;
  struct proc* p;
  uint64 addr;
  int i = 0;
  argaddr(0, &addr);

  // Go through the process table
  for (p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    
    if(p->state != UNUSED){
      // Update the pstat struct
      safestrcpy(st.name[i], p->name, sizeof(p->name));
      st.pid[i] = p->pid;
      if (p->parent){
        st.ppid[i] = p->parent->pid;
      }else{
        st.ppid[i] = 0;
      }
      st.priority[i] = p->priority;
      st.size[i] = p->sz;
      st.state[i] = p->state;

    }else{
      // Mark as to be skipped by user
      st.pid[i] = 0;  
    }

    release(&p->lock);
    i++;
  }

  // Return the info to user
  if (copyout(myproc()->pagetable, addr, (char *)&st, sizeof(st)) < 0){
    return -1;
  }
  return 0;
}
// ------------------ DIT